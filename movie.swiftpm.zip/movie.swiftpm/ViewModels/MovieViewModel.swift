import SwiftUI

class MovieViewModel: ObservableObject {
    @Published var movies: [Movie] = []
    
    func addMovie(movie: Movie) {
        movies.append(movie)
    }
    
    func deleteMovie(at indexSet: IndexSet) {
        movies.remove(atOffsets: indexSet)
    }
    
    func updateMovie(movie: Movie) {
        if let index = movies.firstIndex(where: { $0.id == movie.id }) {
            movies[index] = movie
        }
    }

    
    
    func updateMovieRating(movie: Movie, rating: Double) {
        if let index = movies.firstIndex(where: { $0.id == movie.id }) {
            movies[index].updateRating(newRating: rating)
        }
    }
    
    
    func filterMovies(byGenre genre: Genre? = nil, byRating rating: Double? = nil, searchText: String = "") -> [Movie] {
        var filteredMovies = movies
        
        if let genre = genre {
            filteredMovies = filteredMovies.filter { $0.genre == genre }
        }
        
        if let rating = rating {
            filteredMovies = filteredMovies.filter { $0.rating >= rating }
        }
        
        if !searchText.isEmpty {
            filteredMovies = filteredMovies.filter { $0.title.lowercased().contains(searchText.lowercased()) }
        }
        
        return filteredMovies
    }
}
