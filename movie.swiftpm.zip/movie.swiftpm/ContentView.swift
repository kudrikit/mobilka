import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = MovieViewModel()
    @State private var selectedGenre: Genre?
    @State private var selectedRating: Double = 0.0
    @State private var searchText: String = ""
    @State private var showingAddMovieView = false

    var body: some View {
        NavigationView {
            VStack {
                SearchBar(text: $searchText)
                
                
                HStack {
                    Picker("Жанр", selection: $selectedGenre) {
                        Text("Все жанры").tag(Genre?.none)
                        ForEach(Genre.allCases, id: \.self) { genre in
                            Text(genre.rawValue).tag(genre as Genre?)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(maxWidth: .infinity, alignment: .leading)
                    
                    Stepper(value: $selectedRating, in: 0...5, step: 0.5) {
                                            Text("Рейтинг: \(selectedRating, specifier: "%.1f")")
                                                .font(.subheadline)
                                        }
                    .frame(maxWidth: .infinity, alignment: .trailing)
                }
                .padding(.horizontal)
                
                List {
                    ForEach(viewModel.filterMovies(byGenre: selectedGenre, byRating: selectedRating, searchText: searchText)) { movie in
                        MovieRow(movie: movie, viewModel: viewModel)
                    }
                    .onDelete(perform: viewModel.deleteMovie)
                }
                
                Button(action: {
                    showingAddMovieView = true
                }) {
                    Text("Добавить фильм")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $showingAddMovieView) {
                    AddMovieView(viewModel: viewModel)
                }
            }
            .navigationBarTitle("Фильмы")
        }
    }
}
