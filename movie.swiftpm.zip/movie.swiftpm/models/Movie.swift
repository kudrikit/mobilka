import SwiftUI

struct Movie: Identifiable {
    let id = UUID()
    var title: String
    var description: String
    var genre: Genre
    var image: UIImage
    var rating: Double = 0.0
    var ratingCount: Int = 0
    
    mutating func updateRating(newRating: Double) {
        let totalRating = rating * Double(ratingCount) + newRating
        ratingCount += 1
        rating = totalRating / Double(ratingCount)
    }
}
