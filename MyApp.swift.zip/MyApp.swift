import SwiftUI

class Person: ObservableObject {
    @Published var name: String
    @Published var age: Int
    @Published var city: String

    init(name: String, age: Int, city: String) {
        self.name = name
        self.age = age
        self.city = city
    }

    func changeName(to newName: String) {
        self.name = newName
    }

    func incrementAge() {
        self.age += 1
    }

    func changeCity(to newCity: String) {
        self.city = newCity
    }
}

struct ContentView: View {
    @ObservedObject var person = Person(name: "Alice", age: 30, city: "New York")

    var body: some View {
        VStack {
            Text("Имя: \(person.name)")
            Text("Возраст: \(person.age)")
            Text("Город: \(person.city)")

            Button(action: {
                person.changeName(to: "Bob")
                person.incrementAge()
                person.changeCity(to: "San Francisco")
            }) {
                Text("Обновить информацию")
            }
        }
        .padding()
    }
}

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
