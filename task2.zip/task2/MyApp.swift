import SwiftUI
import PhotosUI

@main
struct MyApp: App {
    var body: some Scene {
        
    
        
        WindowGroup {
            ContentView()
        }
    }
}
